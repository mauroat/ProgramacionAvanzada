package expresionesMatematicas;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.GregorianCalendar;

import org.junit.Test;

public class PolinomioTest_2000 {
/*  TEST 5 - POLINOMIO GRADO 2000*/
	
	@Test
	public void polinomio2000TestCompleto() throws Exception{
		// Genero el archivo de salida
		int n = 2000;
		String miPath = "tests/Salida Esperada/Polinomio "+n+"/";
		long diff;
		
		double res;
		Calendar tIni, tFin;
		// Creo el objeto polinomio 
		Polinomio p = new Polinomio("tests/Entrada/Polinomio_"+n+".in");
		PrintWriter salida = new PrintWriter(new FileWriter(miPath+"Polinomio_"+n+".out"));
		
		// METODO 1 - MULTIPLICACIONES SUCESIVAS
		
		System.out.println("Programacion Multip. Sucesivas:");
		salida.println("Programacion Multip. Sucesivas:");	
		// Inicio la toma de datos
		tIni = new GregorianCalendar();
		// Calculo y muestro el resultado con x=2
		res = p.evaluarMSucesivas(2);				
		System.out.println("Resultado: "+res);
		salida.println("Resultado: "+res);			
		// Fin de toma de datos
		tFin = new GregorianCalendar();
		diff = tFin.getTimeInMillis() - tIni.getTimeInMillis();			
		System.out.println("Tiempo: "+diff+" milisegundos");
		salida.println("Tiempo: "+diff);
		salida.println("");
		salida.println("");
		
		
		// METODO 2 - RECURSIVA
		System.out.println("Programacion Recursiva:");
		salida.println("Programacion Recursiva:");
		// Inicio la toma de datos
		tIni = new GregorianCalendar();
		// Calculo y muestro el resultado con x=2
		res = p.evaluarRecursiva(2);				
		System.out.println("Resultado: "+res);
		salida.println("Resultado: "+res);			
		// Fin de toma de datos
		tFin = new GregorianCalendar();
		diff = tFin.getTimeInMillis() - tIni.getTimeInMillis();			
		System.out.println("Tiempo: "+diff+" milisegundos");
		salida.println("Tiempo: "+diff);
		salida.println("");
		salida.println("");
		
		// METODO 3 - RECURSIVA PAR
		System.out.println("Programacion Recursiva Par:");
		salida.println("Programacion Recursiva Par:");
		// Inicio la toma de datos
		tIni = new GregorianCalendar();
		// Calculo y muestro el resultado con x=2
		res = p.evaluarRecursivaPar(2);				
		System.out.println("Resultado: "+res);
		salida.println("Resultado: "+res);			
		// Fin de toma de datos
		tFin = new GregorianCalendar();
		diff = tFin.getTimeInMillis() - tIni.getTimeInMillis();			
		System.out.println("Tiempo: "+diff+" milisegundos");
		salida.println("Tiempo: "+diff);
		salida.println("");
		salida.println("");
		
		// METODO 4 - MEMORIA DINAMICA
		System.out.println("Programacion Memoria Din�mica:");
		salida.println("Programacion Memoria Din�mica:");
		// Inicio la toma de datos
		tIni = new GregorianCalendar();
		// Calculo y muestro el resultado con x=2
		res = p.evaluarProgDinamica(2);				
		System.out.println("Resultado: "+res);
		salida.println("Resultado: "+res);			
		// Fin de toma de datos
		tFin = new GregorianCalendar();
		diff = tFin.getTimeInMillis() - tIni.getTimeInMillis();			
		System.out.println("Tiempo: "+diff+" milisegundos");
		salida.println("Tiempo: "+diff);
		salida.println("");
		salida.println("");

		// METODO 5 - MEMORIA DINAMICA MEJORADA
		System.out.println("Programacion Din�mica Mejorada:");
		salida.println("Programacion Din�mica Mejorada:");
		// Inicio la toma de datos
		tIni = new GregorianCalendar();
		// Calculo y muestro el resultado con x=2
		res = p.evaluarRecursivaPar(2);				
		System.out.println("Resultado: "+res);
		salida.println("Resultado: "+res);			
		// Fin de toma de datos
		tFin = new GregorianCalendar();
		diff = tFin.getTimeInMillis() - tIni.getTimeInMillis();			
		System.out.println("Tiempo: "+diff+" milisegundos");
		salida.println("Tiempo: "+diff);
		salida.println("");
		salida.println("");
		
		// METODO 6 - POW
		System.out.println("Programacion Pow:");
		salida.println("Programacion Pow:");
		// Inicio la toma de datos
		tIni = new GregorianCalendar();
		// Calculo y muestro el resultado con x=2
		res = p.evaluarPow(2);				
		System.out.println("Resultado: "+res);
		salida.println("Resultado: "+res);			
		// Fin de toma de datos
		tFin = new GregorianCalendar();
		diff = tFin.getTimeInMillis() - tIni.getTimeInMillis();			
		System.out.println("Tiempo: "+diff+" milisegundos");
		salida.println("Tiempo: "+diff);
		salida.println("");
		salida.println("");
		
		// METODO 7 - ALGORITMO DE HORNER
		System.out.println("Programacion Algoritmo de Horner:");
		salida.println("Programacion Algoritmo de Horner:");
		// Inicio la toma de datos
		tIni = new GregorianCalendar();
		// Calculo y muestro el resultado con x=2
		res = p.evaluarHorner(2);				
		System.out.println("Resultado: "+res);
		salida.println("Resultado: "+res);			
		// Fin de toma de datos
		tFin = new GregorianCalendar();
		diff = tFin.getTimeInMillis() - tIni.getTimeInMillis();			
		System.out.println("Tiempo: "+diff+" milisegundos");
		salida.println("Tiempo: "+diff);
		salida.println("");
		salida.println("");
		
		salida.close();
		
	}
}
