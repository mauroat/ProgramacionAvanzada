package selMath;

import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Calendar;

public class SelMath {
	
	/* CONSTRUCTORES */
	
	private int dimension;
	private double error;
	private MatrizMath matriz;
	private VectorMath resultado, incognita;
	
	public SelMath(String path) throws FileNotFoundException, IOException	{
		Locale.setDefault(new Locale("en","US"));
		
		Scanner sc = new Scanner(new File(path));
		
		this.dimension = sc.nextInt();
		this.matriz = new MatrizMath(this.dimension, this.dimension);
		this.resultado = new VectorMath(this.dimension);
		this.incognita = new VectorMath(this.dimension);
		this.error = 0;
		
		for (int i = 0; i < this.dimension; i++){	
			for(int j = 0; j < this.dimension; j++)	{
				int auxFil = sc.nextInt();
				int auxCol = sc.nextInt();
				this.matriz.setValorMatriz(auxFil, auxCol, sc.nextDouble());
			}
		}
		
		for (int i = 0; i < this.dimension; i++)
			this.resultado.setVectorValor(i, sc.nextDouble());
		
		sc.close();		
	}
	
	/* GETTERS */
	
	public int getDimension() {
		return dimension;
	}

	public double getError() {
		return error;
	}

	public MatrizMath getMatriz() {
		return matriz;
	}

	public VectorMath getResultado() {
		return resultado;
	}

	public VectorMath getIncognita() {
		return incognita;
	}
	
	/* SETTERS */
	
	public void setDimension(int dimension) {
		this.dimension = dimension;
	}
	
	public void setError(double error) {
		this.error = error;
	}
	
	public void setMatriz(MatrizMath matriz) {
		this.matriz = matriz;
	}
	
	public void setResultado(VectorMath resultado) {
		this.resultado = resultado;
	}
	
	public void setIncognita(VectorMath incognita) {
		this.incognita = incognita;
	}
	
	
	/* METODOS */
	
	public void mostrarMatriz()	{
		for (int i = 0; i < this.dimension; i++)
			for (int j = 0; j < this.dimension; j++)
				System.out.println(i + " " + j + " " + this.matriz.getValorMatriz(i,j));	
	}
	
	public void mostrarResultados()	{
		for (int i = 0; i < this.dimension; i++)
			System.out.println(this.resultado.getVectorValor(i))	;
	}
	
	public void mostrarIncognitas()	{
		for (int i = 0; i < this.dimension; i++)
			System.out.println(this.incognita.getVectorValor(i))	;
	}
	
	/* CLONE */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SelMath other = (SelMath) obj;
		if (dimension != other.dimension)
			return false;
		if (Double.doubleToLongBits(error) != Double.doubleToLongBits(other.error))
			return false;
		if (incognita == null) {
			if (other.incognita != null)
				return false;
		} else if (!incognita.equals(other.incognita))
			return false;
		if (matriz == null) {
			if (other.matriz != null)
				return false;
		} else if (!matriz.equals(other.matriz))
			return false;
		if (resultado == null) {
			if (other.resultado != null)
				return false;
		} else if (!resultado.equals(other.resultado))
			return false;
		return true;
	}

	// resolver con error / resolver sin error
	public void resolver() throws Exception {
		try {
			
			this.incognita = this.matriz.inversa().producto(this.resultado); // Cambio Nacho 9/9
			calcularErrorSolucion();
			if(this.error > 10E-6) // Cambio Nacho 9/9
				throw new Exception("Hubo un error significativo, el resultado es diferente al obtenido");
		} catch (Exception e) {
			//throw new Exception("El sistema de ecuaciones no tiene soluci�n", e);
		}
	}
	
	public void resolverConError() throws Exception {
		try {
			Calendar tIni = new GregorianCalendar();
			this.incognita = this.matriz.inversa().producto(this.resultado); // Cambio Nacho 9/9
			//this.incognita = new VectorMath (this.matriz.inversa().productoPorVector(this.resultado));
			Calendar tFin = new GregorianCalendar();
			double diff= tFin.getTimeInMillis() - tIni.getTimeInMillis(); 
			System.out.println(diff+" Milisegundos");
			calcularErrorSolucion();
			if(this.error > 10E-6) // Cambio Nacho 9/9
				throw new Exception("Hubo un error significativo, el resultado es diferente al obtenido");
		} catch (Exception e) {
			//throw new Exception("El sistema de ecuaciones no tiene soluci�n", e);
		}
	}
	
	
	/*Revisar, capaz lo copi� mal en clase - (Mauro) Cambi� para que devuelva void, ya que asigna el error ac� (Nacho)*/
	private void calcularErrorSolucion() throws Exception {
		VectorMath aux = new VectorMath(this.matriz.producto(this.incognita));		
		this.error = this.resultado.resta(aux).normaDos();
	}
	
	public void guardarResultado(String path) throws IOException{
		PrintWriter salida = new PrintWriter(new FileWriter(path));  //  preparo el arch de salida
		salida.println(this.dimension);
		for (int i=0; i<this.dimension;i++)
			//System.out.println(this.incognita.getVectorValor(i));
			salida.println(this.incognita.getVectorValor(i));
		salida.println();
		salida.println(this.error);
		salida.close();
	}

	
}
