package selMath;

import org.junit.Test;
import java.io.IOException;
import org.junit.Assert;

public class SelMathTest 
{
	//@Test
	public void testConstructor1() throws Exception, IOException
	{
		SelMath selMath = new SelMath("04_diezPorDiez.in");
		selMath.resolver();
		String pathSalida = "/Salidas/incognitas.out";
		selMath.guardarResultado(pathSalida);
		
	}
	
	//@Test
	public void testGuardarResultado1() throws Exception, IOException
	{
		SelMath sm1 = new SelMath("SelMath1.in");
		String pathSalida = "/test/Salidas.out";
		
		sm1.guardarResultado(pathSalida);
	}
	

	@Test
	public void caso01_2x2() throws Exception, IOException
	{
		SelMath sm1 = new SelMath("test/Entrada/01_2x2.in");
		System.out.println("2 x 2");
		System.out.println(" ");
		sm1.resolverConError();
		sm1.mostrarIncognitas();
		sm1.guardarResultado("test/Salidas/01_2x2.out");
	}
		
	//@Test
	public void caso02_10x10() throws Exception, IOException
	{
		SelMath sm1 = new SelMath("test/Entrada/02_10x10.in");
		System.out.println("10 x 10");
		System.out.println(" ");
		sm1.resolverConError();
		sm1.mostrarIncognitas();
		sm1.guardarResultado("test/Salidas/02_10x10.out");
	}
	
	//@Test
	public void caso03_50x50() throws Exception, IOException
	{
		SelMath sm1 = new SelMath("test/Entrada/03_50x50.in");
		System.out.println("50 x 50");
		System.out.println(" ");
		sm1.resolverConError();
		sm1.mostrarIncognitas();
		sm1.guardarResultado("test/Salidas/03_50x50.out");
	}
	
	//@Test
	public void caso04_80x80() throws Exception, IOException
	{
		SelMath sm1 = new SelMath("test/Entrada/04_80x80.in");
		System.out.println("80 x 80");
		System.out.println(" ");
		sm1.resolverConError();
		sm1.mostrarIncognitas();
		sm1.guardarResultado("test/Salidas/04_80x80.out");
	}
	
	//@Test
	public void caso05_100x100() throws Exception, IOException
	{
		SelMath sm1 = new SelMath("test/Entrada/05_100x100.in");
		System.out.println("100 x 100");
		System.out.println(" ");
		sm1.resolverConError();
		sm1.mostrarIncognitas();
		sm1.guardarResultado("test/Salidas/05_100x100.out");
	}
	
	//@Test
	public void caso06_200x200() throws Exception, IOException
	{
		SelMath sm1 = new SelMath("test/Entrada/06_200x200.in");
		System.out.println("200 x 200");
		System.out.println(" ");
		sm1.resolverConError();
		sm1.mostrarIncognitas();
		sm1.guardarResultado("test/Salidas/06_200x200.out");
	}
	
	//@Test
	public void caso07_300x300() throws Exception, IOException
	{
		SelMath sm1 = new SelMath("test/Entrada/07_300x300.in");
		System.out.println("300 x 300");
		System.out.println(" ");
		sm1.resolverConError();
		sm1.mostrarIncognitas();
		sm1.guardarResultado("test/Salidas/07_300x300.out");
	}
	
	//@Test
	public void caso08_400x400() throws Exception, IOException
	{
		SelMath sm1 = new SelMath("test/Entrada/08_400x400.in");
		System.out.println("400 x 400");
		System.out.println(" ");
		sm1.resolverConError();
		sm1.mostrarIncognitas();
		sm1.guardarResultado("test/Salidas/08_400x400.out");
	}
	
	//@Test
	public void caso09_500x500() throws Exception, IOException
	{
		SelMath sm1 = new SelMath("test/Entrada/09_500x500.in");
		System.out.println("500 x 500");
		System.out.println(" ");
		sm1.resolverConError();
		sm1.mostrarIncognitas();
		sm1.guardarResultado("test/Salidas/09_500x500.out");
	}
	
	//@Test
	public void caso10_1000x1000() throws Exception, IOException
	{
		SelMath sm = new SelMath("test/Entrada/10_1000x1000.in");
		System.out.println("1000 x 1000");
		System.out.println(" ");
		sm.resolverConError();
		sm.mostrarIncognitas();
		System.out.println(" ");
		System.out.println(sm.getError());
		sm.guardarResultado("test/Salidas/10_1000x1000.out");
	}
	
		
		
}
