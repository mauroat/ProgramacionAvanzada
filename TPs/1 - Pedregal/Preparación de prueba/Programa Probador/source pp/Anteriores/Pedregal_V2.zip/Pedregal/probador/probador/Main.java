package probador;

import java.io.FileNotFoundException;
import java.io.IOException;

public class Main {

	public static void main(String[] args) throws FileNotFoundException, IOException 
	{
		String pathIn = "./probador/probador/archivos/1.in";
		String pathOut = "./probador/probador/archivos/1.out";
		
		Terreno terreno = new Terreno(pathIn);
		Casa casa = new Casa(pathIn, pathOut);
		
		System.out.println(terreno.comprobarUbicacion(casa));
	}

}
